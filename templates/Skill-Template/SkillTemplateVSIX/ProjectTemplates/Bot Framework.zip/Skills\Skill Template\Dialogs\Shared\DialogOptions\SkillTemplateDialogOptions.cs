﻿namespace $safeprojectname$.Dialogs.Shared.DialogOptions
{
    public class SkillTemplateDialogOptions
    {
        public bool SkillMode { get; set; }
    }
}