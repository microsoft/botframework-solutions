﻿using Microsoft.Bot.Solutions.Dialogs;

namespace $safeprojectname$.Dialogs.Shared
{
    public class SkillTemplateResponseBuilder : BotResponseBuilder
    {
    }
}