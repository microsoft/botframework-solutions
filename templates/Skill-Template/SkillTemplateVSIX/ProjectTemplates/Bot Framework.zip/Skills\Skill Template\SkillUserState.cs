﻿using Microsoft.Bot.Builder.Dialogs;

namespace $safeprojectname$
{
    public class SkillUserState : DialogState
    {
        public SkillUserState()
        {
        }

        public void Clear()
        {
        }
    }
}